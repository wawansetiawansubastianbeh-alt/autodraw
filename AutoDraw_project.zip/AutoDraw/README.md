# AutoDraw
Menggambar otomatis mengikuti pola gambar dari aplikasi lain.

## Build
- Android Studio: File > Open folder ini > Build > Build APK(s)
- GitHub: push folder ini, lalu ambil APK di tab Actions > Artifacts

## Pakai
1. Buka AutoDraw, beri izin overlay + aktifkan layanan aksesibilitas, tekan "Mulai".
2. Buka aplikasi berisi gambar referensi > tombol melayang "1 · Ambil gambar" > seret area gambar.
3. Buka aplikasi gambar > "2 · Pilih kanvas" > seret area kanvas.
4. Tekan "▶ Mulai gambar". Stop lewat tombol di notifikasi.
