package com.example.autodraw

import android.graphics.Bitmap
import android.graphics.PointF
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max

class TraceResult(val strokes: List<List<PointF>>, val w: Int, val h: Int)

/** Mengubah bitmap menjadi kumpulan goresan garis (polyline). */
object Tracer {

    fun trace(src: Bitmap, maxDim: Int, threshold: Int): TraceResult {
        val scale = minOf(1f, maxDim.toFloat() / max(src.width, src.height))
        val w = max(8, (src.width * scale).toInt())
        val h = max(8, (src.height * scale).toInt())
        val bmp = Bitmap.createScaledBitmap(src, w, h, true)
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)

        val g = IntArray(w * h) {
            val c = px[it]
            (((c shr 16) and 255) * 299 + ((c shr 8) and 255) * 587 + (c and 255) * 114) / 1000
        }

        // Deteksi tepi Sobel
        val edge = BooleanArray(w * h)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            val gx = -g[i - w - 1] + g[i - w + 1] - 2 * g[i - 1] + 2 * g[i + 1] - g[i + w - 1] + g[i + w + 1]
            val gy = -g[i - w - 1] - 2 * g[i - w] - g[i - w + 1] + g[i + w - 1] + 2 * g[i + w] + g[i + w + 1]
            if (abs(gx) + abs(gy) > threshold) edge[i] = true
        }

        thin(edge, w, h)

        // Pelacakan jalur
        val vis = BooleanArray(w * h)
        val paths = ArrayList<List<PointF>>()
        for (pass in 0..1) {
            for (y in 1 until h - 1) for (x in 1 until w - 1) {
                val i = y * w + x
                if (!edge[i] || vis[i]) continue
                if (pass == 0 && countNeighbors(edge, w, x, y) != 1) continue
                vis[i] = true
                val fwd = follow(edge, vis, w, h, x, y)
                val back = follow(edge, vis, w, h, x, y)
                val p = ArrayList<PointF>()
                p.addAll(back.asReversed())
                p.add(PointF(x.toFloat(), y.toFloat()))
                p.addAll(fwd)
                if (p.size >= 4) paths.add(rdp(p, 1.0f))
            }
        }
        return TraceResult(order(paths), w, h)
    }

    private val DX = intArrayOf(1, -1, 0, 0, 1, -1, 1, -1)
    private val DY = intArrayOf(0, 0, 1, -1, 1, 1, -1, -1)

    private fun countNeighbors(img: BooleanArray, w: Int, x: Int, y: Int): Int {
        var c = 0
        for (d in 0 until 8) if (img[(y + DY[d]) * w + (x + DX[d])]) c++
        return c
    }

    private fun follow(img: BooleanArray, vis: BooleanArray, w: Int, h: Int, sx: Int, sy: Int): ArrayList<PointF> {
        val out = ArrayList<PointF>()
        var x = sx
        var y = sy
        while (true) {
            var found = false
            for (d in 0 until 8) {
                val nx = x + DX[d]
                val ny = y + DY[d]
                if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                val ni = ny * w + nx
                if (img[ni] && !vis[ni]) {
                    vis[ni] = true
                    out.add(PointF(nx.toFloat(), ny.toFloat()))
                    x = nx
                    y = ny
                    found = true
                    break
                }
            }
            if (!found) break
        }
        return out
    }

    /** Zhang-Suen thinning */
    private fun thin(img: BooleanArray, w: Int, h: Int) {
        val toClear = ArrayList<Int>()
        var changed = true
        while (changed) {
            changed = false
            for (step in 0..1) {
                toClear.clear()
                for (y in 1 until h - 1) for (x in 1 until w - 1) {
                    val i = y * w + x
                    if (!img[i]) continue
                    val p2 = img[i - w]; val p3 = img[i - w + 1]; val p4 = img[i + 1]; val p5 = img[i + w + 1]
                    val p6 = img[i + w]; val p7 = img[i + w - 1]; val p8 = img[i - 1]; val p9 = img[i - w - 1]
                    var b = 0
                    if (p2) b++; if (p3) b++; if (p4) b++; if (p5) b++
                    if (p6) b++; if (p7) b++; if (p8) b++; if (p9) b++
                    if (b < 2 || b > 6) continue
                    var a = 0
                    if (!p2 && p3) a++; if (!p3 && p4) a++; if (!p4 && p5) a++; if (!p5 && p6) a++
                    if (!p6 && p7) a++; if (!p7 && p8) a++; if (!p8 && p9) a++; if (!p9 && p2) a++
                    if (a != 1) continue
                    if (step == 0) {
                        if (p2 && p4 && p6) continue
                        if (p4 && p6 && p8) continue
                    } else {
                        if (p2 && p4 && p8) continue
                        if (p2 && p6 && p8) continue
                    }
                    toClear.add(i)
                }
                if (toClear.isNotEmpty()) {
                    changed = true
                    for (i in toClear) img[i] = false
                }
            }
        }
    }

    /** Ramer-Douglas-Peucker */
    private fun rdp(pts: List<PointF>, eps: Float): List<PointF> {
        if (pts.size < 3) return pts
        val keep = BooleanArray(pts.size)
        keep[0] = true
        keep[pts.size - 1] = true
        val stack = ArrayDeque<IntArray>()
        stack.add(intArrayOf(0, pts.size - 1))
        while (stack.isNotEmpty()) {
            val seg = stack.removeLast()
            val a = seg[0]
            val b = seg[1]
            if (b <= a + 1) continue
            val ax = pts[a].x; val ay = pts[a].y
            val dx = pts[b].x - ax; val dy = pts[b].y - ay
            val len = hypot(dx, dy)
            var maxD = -1f
            var idx = -1
            for (i in a + 1 until b) {
                val d = if (len == 0f) hypot(pts[i].x - ax, pts[i].y - ay)
                else abs(dy * (pts[i].x - ax) - dx * (pts[i].y - ay)) / len
                if (d > maxD) { maxD = d; idx = i }
            }
            if (maxD > eps && idx > 0) {
                keep[idx] = true
                stack.add(intArrayOf(a, idx))
                stack.add(intArrayOf(idx, b))
            }
        }
        return pts.filterIndexed { i, _ -> keep[i] }
    }

    /** Urutkan goresan dengan nearest-neighbour agar loncatan jari minim. */
    private fun order(paths: List<List<PointF>>): List<List<PointF>> {
        val remaining = paths.toMutableList()
        val res = ArrayList<List<PointF>>(paths.size)
        var cx = 0f
        var cy = 0f
        while (remaining.isNotEmpty()) {
            var best = -1
            var bestD = Float.MAX_VALUE
            var rev = false
            for (i in remaining.indices) {
                val p = remaining[i]
                val d1 = sq(p.first().x - cx, p.first().y - cy)
                val d2 = sq(p.last().x - cx, p.last().y - cy)
                if (d1 < bestD) { bestD = d1; best = i; rev = false }
                if (d2 < bestD) { bestD = d2; best = i; rev = true }
            }
            val p = remaining.removeAt(best)
            val q = if (rev) p.reversed() else p
            res.add(q)
            cx = q.last().x
            cy = q.last().y
        }
        return res
    }

    private fun sq(dx: Float, dy: Float) = dx * dx + dy * dy
}
