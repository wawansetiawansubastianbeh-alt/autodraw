package com.example.autodraw

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min

/** Layar penuh transparan untuk memilih area dengan menyeret jari. */
class SelectionView(
    context: Context,
    private val title: String,
    private val onResult: (Rect?) -> Unit
) : View(context) {

    private val dim = Paint().apply { color = 0x99000000.toInt() }
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF00E5FF.toInt(); style = Paint.Style.STROKE; strokeWidth = 4f
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 42f; textAlign = Paint.Align.CENTER
    }
    private var x0 = 0f
    private var y0 = 0f
    private var x1 = 0f
    private var y1 = 0f
    private var active = false
    private var finished = false

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (!active) {
            canvas.drawRect(0f, 0f, w, h, dim)
        } else {
            val l = min(x0, x1); val r = max(x0, x1)
            val t = min(y0, y1); val b = max(y0, y1)
            canvas.drawRect(0f, 0f, w, t, dim)
            canvas.drawRect(0f, b, w, h, dim)
            canvas.drawRect(0f, t, l, b, dim)
            canvas.drawRect(r, t, w, b, dim)
            canvas.drawRect(l, t, r, b, border)
        }
        canvas.drawText(title, w / 2, 140f, text)
        canvas.drawText("Seret untuk memilih area · ketuk singkat = batal", w / 2, 200f, text.apply { textSize = 30f })
        text.textSize = 42f
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                x0 = e.rawX - locationX(); y0 = e.rawY - locationY()
                x1 = x0; y1 = y0; active = true
            }
            MotionEvent.ACTION_MOVE -> {
                x1 = e.x; y1 = e.y
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                x1 = e.x; y1 = e.y
                if (!finished) {
                    finished = true
                    val r = Rect(min(x0, x1).toInt(), min(y0, y1).toInt(), max(x0, x1).toInt(), max(y0, y1).toInt())
                    onResult(if (r.width() < 40 || r.height() < 40) null else r)
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                if (!finished) { finished = true; onResult(null) }
            }
        }
        return true
    }

    private fun locationX(): Float { val l = IntArray(2); getLocationOnScreen(l); return l[0].toFloat() }
    private fun locationY(): Float { val l = IntArray(2); getLocationOnScreen(l); return l[1].toFloat() }
}
