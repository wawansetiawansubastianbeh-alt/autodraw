package com.example.autodraw

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var info: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(56, 96, 56, 56)
        }
        root.addView(TextView(this).apply {
            text = "AutoDraw"
            textSize = 28f
            setTextColor(Color.BLACK)
        })
        info = TextView(this).apply {
            textSize = 14f
            setPadding(0, 24, 0, 24)
        }
        root.addView(info)

        fun button(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label
            gravity = Gravity.CENTER
            setOnClickListener { onClick() }
        }

        root.addView(button("1. Izinkan tampil di atas aplikasi lain") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        root.addView(button("2. Aktifkan layanan aksesibilitas") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("3. Mulai AutoDraw") { start() })

        root.addView(TextView(this).apply {
            textSize = 12f
            setPadding(0, 32, 0, 0)
            text = "Saat diminta berbagi layar, pilih \"Seluruh layar\" (bukan satu aplikasi).\n\n" +
                    "Jika tombol aksesibilitas abu-abu (APK dari luar Play Store): buka Info Aplikasi AutoDraw → " +
                    "menu ⋮ → \"Izinkan setelan terbatas\", lalu ulangi langkah 2."
        })
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val ov = Settings.canDrawOverlays(this)
        val acc = DrawAccessibilityService.instance != null
        info.text = "Tampil di atas aplikasi lain: ${if (ov) "✓ aktif" else "✗ belum"}\n" +
                "Layanan aksesibilitas: ${if (acc) "✓ aktif" else "✗ belum"}"
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izinkan overlay dulu (langkah 1)", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), 100)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, OverlayService::class.java)
                .setAction(OverlayService.ACTION_START)
                .putExtra("code", resultCode)
                .putExtra("data", data)
            startForegroundService(i)
            moveTaskToBack(true)
        }
    }
}
